import {
  jsonToYaml,
  yamlToJson,
  base64Encode,
  base64Decode,
  hexToAscii,
  asciiToHex,
  md5,
  sha1,
  sha256,
  aesEncrypt,
  aesDecrypt,
  toCamel,
  toSnake,
  pxToRem,
  unixToDate,
  dateToUnix,
} from '../src/lib/converters';

describe('Converter Functions', () => {
  test('JSON <-> YAML', () => {
    const json = '{"foo":1,"bar":[2,3]}';
    const yaml = jsonToYaml(json);
    expect(yaml).toContain('foo: 1');
    expect(yamlToJson(yaml)).toEqual(JSON.stringify(JSON.parse(json), null, 2));
  });

  test('Base64 Encode/Decode', () => {
    const text = 'hello world';
    const enc = base64Encode(text);
    expect(base64Decode(enc)).toBe(text);
  });

  test('Hex <-> ASCII', () => {
    const ascii = 'Hello';
    const hex = asciiToHex(ascii);
    expect(hexToAscii(hex)).toBe(ascii);
  });

  test('MD5/SHA1/SHA256', () => {
    const text = 'test';
    expect(md5(text)).toHaveLength(32);
    expect(sha1(text)).toHaveLength(40);
    expect(sha256(text)).toHaveLength(64);
  });

  test('AES Demo', () => {
    const plain = 'my secret';
    const pass = 'pw';
    const enc = aesEncrypt(plain, pass);
    expect(aesDecrypt(enc, pass)).toBe(plain);
  });

  test('Camel/Snake Case', () => {
    expect(toCamel('hello_world')).toBe('helloWorld');
    expect(toSnake('HelloWorld')).toBe('hello_world');
  });

  test('px <-> rem', () => {
    expect(pxToRem(32)).toBe(2);
  });

  test('Unix Timestamp <-> Date', () => {
    const ts = 1694851200;
    const date = unixToDate(ts);
    expect(typeof date).toBe('string');
    expect(Math.abs(dateToUnix(date) - ts)).toBeLessThan(2);
  });
});