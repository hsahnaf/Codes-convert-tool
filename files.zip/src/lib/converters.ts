import yaml from 'js-yaml';
import { Base64 } from 'js-base64';
import { parse as parseCSV, unparse as unparseCSV } from 'papaparse';
import { xml2js, js2xml } from 'xml-js';
import cryptoJs from 'crypto-js';

// --- JSON/XML/YAML/CSV ---
export function jsonToYaml(json: string): string {
  return yaml.dump(JSON.parse(json));
}

export function yamlToJson(yamlStr: string): string {
  return JSON.stringify(yaml.load(yamlStr), null, 2);
}

export function jsonToXml(json: string): string {
  return js2xml(JSON.parse(json), { compact: true, spaces: 2 });
}

export function xmlToJson(xml: string): string {
  return JSON.stringify(xml2js(xml, { compact: true }), null, 2);
}

export function jsonToCsv(json: string): string {
  const arr = JSON.parse(json);
  return unparseCSV(arr);
}

export function csvToJson(csv: string): string {
  const result = parseCSV(csv, { header: true });
  return JSON.stringify(result.data, null, 2);
}

// --- Base64 ---
export function base64Encode(str: string): string {
  return Base64.encode(str);
}

export function base64Decode(str: string): string {
  return Base64.decode(str);
}

// --- URL ---
export function urlEncode(str: string): string {
  return encodeURIComponent(str);
}

export function urlDecode(str: string): string {
  return decodeURIComponent(str);
}

// --- Hex/Bin/ASCII/Dec ---
export function hexToBin(hex: string): string {
  return hex.match(/.{1,2}/g)?.map(h => parseInt(h, 16).toString(2).padStart(8, '0')).join(' ') || '';
}

export function binToHex(bin: string): string {
  return bin.replace(/ +/g, '').match(/.{1,8}/g)?.map(b => parseInt(b, 2).toString(16).padStart(2, '0')).join('') || '';
}

export function hexToAscii(hex: string): string {
  return hex.match(/.{1,2}/g)?.map(h => String.fromCharCode(parseInt(h, 16))).join('') || '';
}

export function asciiToHex(ascii: string): string {
  return Array.from(ascii).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('');
}

export function decToHex(dec: string): string {
  return parseInt(dec, 10).toString(16);
}

export function hexToDec(hex: string): string {
  return parseInt(hex, 16).toString(10);
}

export function binToAscii(bin: string): string {
  return bin.match(/.{1,8}/g)?.map(b => String.fromCharCode(parseInt(b, 2))).join('') || '';
}

export function asciiToBin(ascii: string): string {
  return Array.from(ascii).map(c => c.charCodeAt(0).toString(2).padStart(8, '0')).join(' ');
}

export function decToBin(dec: string): string {
  return parseInt(dec, 10).toString(2);
}

export function binToDec(bin: string): string {
  return parseInt(bin, 2).toString(10);
}

// --- Markdown/HTML/JSX ---
import remark from 'remark';
import remarkHtml from 'remark-html';

export async function markdownToHtml(markdown: string): Promise<string> {
  const result = await remark().use(remarkHtml).process(markdown);
  return result.toString();
}

export function htmlToMarkdown(html: string): string {
  // Simple HTML to Markdown (not perfect)
  return html.replace(/<[^>]+>/g, '');
}

export function htmlToJsx(html: string): string {
  // Very naive replacement (real-world: use html-to-jsx libraries)
  return html.replace(/class=/g, 'className=');
}

export function jsxToHtml(jsx: string): string {
  return jsx.replace(/className=/g, 'class=');
}

// --- HTML Entities ---
export function encodeHtmlEntities(str: string): string {
  return str.replace(/[\u00A0-\u9999<>&]/gim, i => `&#${i.charCodeAt(0)};`);
}

export function decodeHtmlEntities(str: string): string {
  return str.replace(/&#(\d+);/g, (m, code) => String.fromCharCode(+code));
}

// --- Hash ---
export function md5(str: string): string {
  return cryptoJs.MD5(str).toString();
}

export function sha1(str: string): string {
  return cryptoJs.SHA1(str).toString();
}

export function sha256(str: string): string {
  return cryptoJs.SHA256(str).toString();
}

// --- AES ---
export function aesEncrypt(plaintext: string, password: string): string {
  return cryptoJs.AES.encrypt(plaintext, password).toString();
}

export function aesDecrypt(ciphertext: string, password: string): string {
  try {
    const bytes = cryptoJs.AES.decrypt(ciphertext, password);
    return bytes.toString(cryptoJs.enc.Utf8);
  } catch {
    return '';
  }
}

// --- Color ---
export function hexToRgb(hex: string): string {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  const n = parseInt(c, 16);
  return `rgb(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255})`;
}

export function rgbToHex(rgb: string): string {
  const m = rgb.match(/\d+/g);
  if (!m) return '';
  return (
    '#' +
    m
      .slice(0, 3)
      .map(x => (+x).toString(16).padStart(2, '0'))
      .join('')
  );
}

export function rgbToHsl(rgb: string): string {
  const m = rgb.match(/\d+/g);
  if (!m) return '';
  let [r, g, b] = m.map(Number).map(v => v / 255);
  let max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  if (max !== min) {
    let d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
}

export function hslToRgb(hsl: string): string {
  const m = hsl.match(/\d+/g);
  if (!m) return '';
  let h = +m[0] / 360, s = +m[1] / 100, l = +m[2] / 100;
  let r, g, b;
  if (s === 0) r = g = b = l;
  else {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return `rgb(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)})`;
}

export function hexToHsl(hex: string): string {
  return rgbToHsl(hexToRgb(hex));
}

export function hslToHex(hsl: string): string {
  return rgbToHex(hslToRgb(hsl));
}

// --- Units ---
export function pxToRem(px: number, base = 16): number {
  return px / base;
}
export function remToPx(rem: number, base = 16): number {
  return rem * base;
}
export function pxToEm(px: number, context = 16): number {
  return px / context;
}
export function emToPx(em: number, context = 16): number {
  return em * context;
}

// --- Timestamp/Date ---
import { DateTime } from 'luxon';

export function unixToDate(ts: number): string {
  return DateTime.fromSeconds(ts).toISO();
}
export function dateToUnix(dateStr: string): number {
  return DateTime.fromISO(dateStr).toSeconds();
}

// --- Text Case ---
export function toUpper(str: string): string {
  return str.toUpperCase();
}
export function toLower(str: string): string {
  return str.toLowerCase();
}
export function toTitle(str: string): string {
  return str.replace(/\w\S*/g, w => w[0].toUpperCase() + w.slice(1).toLowerCase());
}
export function toCamel(str: string): string {
  return str
    .replace(/([-_ ][a-z])/gi, s => s.toUpperCase().replace(/[-_ ]/g, ''))
    .replace(/^./, s => s.toLowerCase());
}
export function toSnake(str: string): string {
  return str
    .replace(/\s+/g, '_')
    .replace(/[A-Z]/g, (l) => `_${l.toLowerCase()}`)
    .replace(/^_+/, '')
    .toLowerCase();
}

// --- CSS/SCSS ---
export function cssToScss(css: string): string {
  // Simple: replace ; with ;\n  and nest rules with braces (not real parser!)
  return css.replace(/; */g, ';\n  ').replace(/{/g, '{\n  ').replace(/}/g, '\n}');
}
export function scssToCss(scss: string): string {
  // Remove extra whitespace and flatten indent
  return scss.replace(/\n\s*/g, '').replace(/}/g, '} ');
}

// --- Code Beautify/Minify ---
import beautify from 'js-beautify';

export function beautifyCode(code: string, type: 'js'|'css'|'html'): string {
  switch (type) {
    case 'js': return beautify.js(code);
    case 'css': return beautify.css(code);
    case 'html': return beautify.html(code);
    default: return code;
  }
}
export function minifyCode(code: string, type: 'js'|'css'|'html'): string {
  switch (type) {
    case 'js': return beautify.js(code, { indent_size: 0, space_in_empty_paren: false });
    case 'css': return beautify.css(code, { indent_size: 0 });
    case 'html': return beautify.html(code, { indent_size: 0 });
    default: return code;
  }
}