import React, { useState, useEffect, useCallback } from 'react';
import { ToolSidebar } from './components/layout/ToolSidebar';
import { TopBar } from './components/layout/TopBar';
import { ToolContent } from './components/layout/ToolContent';
import { tools, ToolKey, getToolByKey } from './components/tools/registry';
import { Toaster } from 'react-hot-toast';

const getInitialTheme = () => {
  if (typeof window !== 'undefined') {
    return (
      localStorage.getItem('theme') ||
      (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    );
  }
  return 'light';
};

function App() {
  const [theme, setTheme] = useState(getInitialTheme());
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<ToolKey>('json-xml-yaml-csv');

  // Theme management
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        const input = document.getElementById('toolbar-search');
        input?.focus();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  // Filter tools for sidebar
  const filteredTools = tools.filter(
    (t) =>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.keywords.some((kw) => kw.includes(search.toLowerCase()))
  );

  // For keyboard navigation (Ctrl+K)
  const handleSearch = useCallback((val: string) => setSearch(val), []);

  return (
    <div className="min-h-screen flex flex-col">
      <TopBar
        theme={theme}
        setTheme={setTheme}
        search={search}
        setSearch={handleSearch}
      />
      <div className="flex flex-1 overflow-hidden">
        <ToolSidebar
          tools={filteredTools}
          selected={selected}
          setSelected={setSelected}
        />
        <main className="flex-1 bg-white dark:bg-gray-900 p-4 overflow-auto">
          <ToolContent tool={getToolByKey(selected)} />
        </main>
      </div>
      <Toaster position="top-right" />
    </div>
  );
}

export default App;