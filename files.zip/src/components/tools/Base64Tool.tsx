import React, { useState, useCallback } from 'react';
import * as conv from '../../lib/converters';
import Prism from 'prismjs';
import { toast } from 'react-hot-toast';
import debounce from 'lodash.debounce';

const sample = 'hello world';

export default function Base64Tool() {
  const [input, setInput] = useState(sample);
  const [mode, setMode] = useState<'encode'|'decode'>('encode');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');

  const convert = useCallback(() => {
    try {
      setError('');
      setOutput(mode === 'encode' ? conv.base64Encode(input) : conv.base64Decode(input));
    } catch (e: any) {
      setOutput('');
      setError('Invalid input.');
    }
  }, [input, mode]);

  // Debounce conversion
  const debouncedConvert = useCallback(debounce(convert, 350), [convert]);
  React.useEffect(() => {
    debouncedConvert();
    return debouncedConvert.cancel;
  }, [input, mode, debouncedConvert]);

  return (
    <div>
      <div className="mb-2 flex gap-2">
        <select value={mode} onChange={e => setMode(e.target.value as 'encode'|'decode')}>
          <option value="encode">Encode</option>
          <option value="decode">Decode</option>
        </select>
        <button className="btn-action ml-2" onClick={convert}>Convert</button>
        <button className="btn-action" onClick={() => setInput('')}>Clear</button>
        <button className="btn-action" disabled={!output} onClick={() => {navigator.clipboard.writeText(output);toast.success('Copied!');}}>Copy</button>
      </div>
      <p className="mb-1 text-gray-500 text-sm">Supports text and small files. For files, paste content as string.</p>
      <div className="flex gap-4">
        <textarea className="w-1/2 min-h-[120px] p-2 rounded border" value={input} onChange={e=>setInput(e.target.value)} />
        <div className="w-1/2 min-h-[120px] bg-gray-100 dark:bg-gray-800 p-2 rounded border overflow-auto">
          {error ? (
            <span className="text-red-500">{error}</span>
          ) : (
            <pre className="text-xs whitespace-pre-wrap">{output}</pre>
          )}
        </div>
      </div>
      <div className="mt-2 text-xs text-gray-400">
        Example: <code>{sample}</code>
      </div>
    </div>
  );
}