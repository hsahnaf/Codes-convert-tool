import React, { useState, useCallback } from 'react';
import * as conv from '../../lib/converters';
import debounce from 'lodash.debounce';
import { toast } from 'react-hot-toast';

export default function ColorTool() {
  const [input, setInput] = useState('#FF8800');
  const [mode, setMode] = useState<'hex'|'rgb'|'hsl'>('hex');
  const [output, setOutput] = useState({ hex: '', rgb: '', hsl: '' });
  const [error, setError] = useState('');

  const convert = useCallback(() => {
    try {
      let hex = '', rgb = '', hsl = '';
      if (mode === 'hex') {
        hex = input;
        rgb = conv.hexToRgb(input);
        hsl = conv.hexToHsl(input);
      } else if (mode === 'rgb') {
        rgb = input;
        hex = conv.rgbToHex(input);
        hsl = conv.rgbToHsl(input);
      } else if (mode === 'hsl') {
        hsl = input;
        rgb = conv.hslToRgb(input);
        hex = conv.hslToHex(input);
      }
      setOutput({ hex, rgb, hsl });
      setError('');
    } catch {
      setError('Invalid color value.');
      setOutput({ hex: '', rgb: '', hsl: '' });
    }
  }, [input, mode]);

  const debouncedConvert = useCallback(debounce(convert, 300), [convert]);
  React.useEffect(() => {
    debouncedConvert();
    return debouncedConvert.cancel;
  }, [input, mode, debouncedConvert]);

  return (
    <div>
      <div className="mb-2 flex gap-2">
        <select value={mode} onChange={e => setMode(e.target.value as any)}>
          <option value="hex">HEX</option>
          <option value="rgb">RGB</option>
          <option value="hsl">HSL</option>
        </select>
        <button className="btn-action ml-2" onClick={convert}>Convert</button>
        <button className="btn-action" onClick={() => setInput('')}>Clear</button>
      </div>
      <p className="mb-1 text-gray-500 text-sm">
        Enter a color in HEX, RGB, or HSL. See conversions and preview below.
      </p>
      <div className="flex gap-4 items-center">
        <input
          className="w-1/2 p-2 rounded border"
          value={input}
          onChange={e => setInput(e.target.value)}
        />
        <div className="w-1/2 flex flex-col gap-1">
          {error ? (
            <span className="text-red-500">{error}</span>
          ) : (
            <>
              <div>
                <span className="font-mono text-xs">HEX: </span>
                <span className="cursor-pointer" onClick={() => {navigator.clipboard.writeText(output.hex);toast.success('Copied!')}}>{output.hex}</span>
              </div>
              <div>
                <span className="font-mono text-xs">RGB: </span>
                <span className="cursor-pointer" onClick={() => {navigator.clipboard.writeText(output.rgb);toast.success('Copied!')}}>{output.rgb}</span>
              </div>
              <div>
                <span className="font-mono text-xs">HSL: </span>
                <span className="cursor-pointer" onClick={() => {navigator.clipboard.writeText(output.hsl);toast.success('Copied!')}}>{output.hsl}</span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-xs">Preview:</span>
                <span className="inline-block w-6 h-6 rounded border" style={{ background: output.hex }}></span>
              </div>
            </>
          )}
        </div>
      </div>
      <div className="mt-2 text-xs text-gray-400">
        Example: <code>#FF8800</code> or <code>rgb(255,136,0)</code>
      </div>
    </div>
  );
}