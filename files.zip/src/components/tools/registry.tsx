import { DocumentTextIcon, LinkIcon, HashtagIcon, CalendarIcon, CodeBracketIcon, PaintBrushIcon, KeyIcon, TableCellsIcon, EyeIcon, ArrowsRightLeftIcon, PencilSquareIcon } from '@heroicons/react/24/outline';

import JsonXmlYamlCsvTool from './JsonXmlYamlCsvTool';
import Base64Tool from './Base64Tool';
import UrlTool from './UrlTool';
import HexBinAsciiTool from './HexBinAsciiTool';
import MarkdownHtmlJsxTool from './MarkdownHtmlJsxTool';
import HtmlEntityTool from './HtmlEntityTool';
import JwtDecoderTool from './JwtDecoderTool';
import HashTool from './HashTool';
import AesTool from './AesTool';
import ColorTool from './ColorTool';
import UnitTool from './UnitTool';
import TimestampTool from './TimestampTool';
import TextCaseTool from './TextCaseTool';
import CssScssTool from './CssScssTool';
import CodeBeautifyTool from './CodeBeautifyTool';

export type ToolKey =
  | "json-xml-yaml-csv"
  | "base64"
  | "url"
  | "hex-bin-ascii"
  | "markdown-html-jsx"
  | "html-entity"
  | "jwt"
  | "hash"
  | "aes"
  | "color"
  | "unit"
  | "timestamp"
  | "text-case"
  | "css-scss"
  | "code-beautify";

export type ToolMeta = {
  key: ToolKey;
  name: string;
  description: string;
  keywords: string[];
  icon?: React.FC<React.SVGProps<SVGSVGElement>>;
  Component: React.FC;
};

export const tools: ToolMeta[] = [
  {
    key: "json-xml-yaml-csv",
    name: "JSON ↔ XML ↔ YAML ↔ CSV",
    description: "Convert, validate, pretty-print, minify, and download between JSON, XML, YAML, and CSV.",
    keywords: ["json", "xml", "yaml", "csv", "format"],
    icon: TableCellsIcon,
    Component: JsonXmlYamlCsvTool,
  },
  {
    key: "base64",
    name: "Base64 Encode/Decode",
    description: "Encode or decode text and files in Base64.",
    keywords: ["base64", "encode", "decode", "file"],
    icon: KeyIcon,
    Component: Base64Tool,
  },
  {
    key: "url",
    name: "URL Encode/Decode",
    description: "Encode or decode URL text.",
    keywords: ["url", "encode", "decode", "uri"],
    icon: LinkIcon,
    Component: UrlTool,
  },
  {
    key: "hex-bin-ascii",
    name: "Hex ↔ Binary ↔ ASCII ↔ Decimal",
    description: "Convert between hexadecimal, binary, ASCII, and decimal representations.",
    keywords: ["hex", "binary", "ascii", "decimal", "number"],
    icon: HashtagIcon,
    Component: HexBinAsciiTool,
  },
  {
    key: "markdown-html-jsx",
    name: "Markdown ↔ HTML ↔ JSX",
    description: "Convert between Markdown, HTML, and basic JSX.",
    keywords: ["markdown", "html", "jsx"],
    icon: PencilSquareIcon,
    Component: MarkdownHtmlJsxTool,
  },
  {
    key: "html-entity",
    name: "HTML Entity Encode/Decode",
    description: "Encode or decode HTML entities.",
    keywords: ["html", "entity", "encode", "decode"],
    icon: CodeBracketIcon,
    Component: HtmlEntityTool,
  },
  {
    key: "jwt",
    name: "JWT Decoder",
    description: "Decode and inspect JWT token headers and payloads.",
    keywords: ["jwt", "token", "decode"],
    icon: EyeIcon,
    Component: JwtDecoderTool
  },
  {
    key: "hash",
    name: "Hash Functions",
    description: "Generate MD5, SHA1, and SHA256 hashes.",
    keywords: ["md5", "sha1", "sha256", "hash"],
    icon: HashtagIcon,
    Component: HashTool
  },
  {
    key: "aes",
    name: "AES Encrypt/Decrypt Demo",
    description: "Password-based AES encryption/decryption (demo only).",
    keywords: ["aes", "encryption", "decryption", "crypto"],
    icon: KeyIcon,
    Component: AesTool
  },
  {
    key: "color",
    name: "Color Converter",
    description: "Convert between HEX, RGB, HSL and preview color.",
    keywords: ["hex", "rgb", "hsl", "color"],
    icon: PaintBrushIcon,
    Component: ColorTool
  },
  {
    key: "unit",
    name: "Unit Converter",
    description: "Convert px, rem, em and common length units.",
    keywords: ["unit", "px", "rem", "em", "length"],
    icon: ArrowsRightLeftIcon,
    Component: UnitTool
  },
  {
    key: "timestamp",
    name: "Unix Timestamp ↔ Date",
    description: "Convert Unix timestamps to human dates and vice versa.",
    keywords: ["timestamp", "date", "unix", "time"],
    icon: CalendarIcon,
    Component: TimestampTool
  },
  {
    key: "text-case",
    name: "Text Case Converter",
    description: "Convert text to upper/lower/title/camel/snake case.",
    keywords: ["case", "upper", "lower", "camel", "snake", "title"],
    icon: DocumentTextIcon,
    Component: TextCaseTool
  },
  {
    key: "css-scss",
    name: "CSS ↔ SCSS Converter",
    description: "Convert CSS to basic SCSS and vice versa.",
    keywords: ["css", "scss", "sass", "convert"],
    icon: PaintBrushIcon,
    Component: CssScssTool
  },
  {
    key: "code-beautify",
    name: "Code Beautify/Minify",
    description: "Beautify or minify JS, HTML, or CSS code.",
    keywords: ["beautify", "minify", "js", "html", "css"],
    icon: CodeBracketIcon,
    Component: CodeBeautifyTool
  },
];

export function getToolByKey(key: ToolKey): ToolMeta {
  return tools.find((t) => t.key === key) || tools[0];
}