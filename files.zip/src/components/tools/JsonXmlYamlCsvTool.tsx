import React, { useState, useCallback } from 'react';
import * as conv from '../../lib/converters';
import Prism from 'prismjs';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-yaml';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-csv';
import { toast } from 'react-hot-toast';
import debounce from 'lodash.debounce';

const sample = `{
  "foo": 42,
  "bar": [1, 2, 3],
  "baz": { "qux": "hello" }
}`;

const formats = [
  { label: 'JSON', value: 'json' },
  { label: 'YAML', value: 'yaml' },
  { label: 'XML', value: 'xml' },
  { label: 'CSV', value: 'csv' },
];

type Format = 'json' | 'yaml' | 'xml' | 'csv';

export default function JsonXmlYamlCsvTool() {
  const [input, setInput] = useState(sample);
  const [inputFormat, setInputFormat] = useState<Format>('json');
  const [outputFormat, setOutputFormat] = useState<Format>('yaml');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');

  const convert = useCallback(() => {
    try {
      let res = '';
      if (inputFormat === outputFormat) {
        res = input;
      } else if (inputFormat === 'json') {
        if (outputFormat === 'yaml') res = conv.jsonToYaml(input);
        if (outputFormat === 'xml') res = conv.jsonToXml(input);
        if (outputFormat === 'csv') res = conv.jsonToCsv(input);
      } else if (inputFormat === 'yaml') {
        const jsonStr = conv.yamlToJson(input);
        if (outputFormat === 'json') res = jsonStr;
        if (outputFormat === 'xml') res = conv.jsonToXml(jsonStr);
        if (outputFormat === 'csv') res = conv.jsonToCsv(jsonStr);
      } else if (inputFormat === 'xml') {
        const jsonStr = conv.xmlToJson(input);
        if (outputFormat === 'json') res = jsonStr;
        if (outputFormat === 'yaml') res = conv.jsonToYaml(jsonStr);
        if (outputFormat === 'csv') res = conv.jsonToCsv(jsonStr);
      } else if (inputFormat === 'csv') {
        const jsonStr = conv.csvToJson(input);
        if (outputFormat === 'json') res = jsonStr;
        if (outputFormat === 'yaml') res = conv.jsonToYaml(jsonStr);
        if (outputFormat === 'xml') res = conv.jsonToXml(jsonStr);
      }
      setOutput(res);
      setError('');
    } catch (e: any) {
      setOutput('');
      setError('Invalid input or conversion error.');
    }
  }, [input, inputFormat, outputFormat]);

  // Debounce conversion
  const debouncedConvert = useCallback(debounce(convert, 400), [convert]);
  React.useEffect(() => {
    debouncedConvert();
    return debouncedConvert.cancel;
  }, [input, inputFormat, outputFormat, debouncedConvert]);

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
    toast.success('Output copied!');
  };
  const handleDownload = () => {
    const blob = new Blob([output], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `output.${outputFormat}`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success('Downloaded!');
  };

  return (
    <div>
      <div className="mb-2 flex flex-wrap gap-2">
        <div>
          <label className="mr-1">Input Format:</label>
          <select value={inputFormat} onChange={e => setInputFormat(e.target.value as Format)}>
            {formats.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
        </div>
        <div>
          <label className="mr-1">Output Format:</label>
          <select value={outputFormat} onChange={e => setOutputFormat(e.target.value as Format)}>
            {formats.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
        </div>
        <button className="btn-action ml-2" onClick={convert} title="Convert (Ctrl+Enter)">
          Convert
        </button>
        <button className="btn-action" onClick={() => setInput('')}>Clear</button>
        <button className="btn-action" disabled={!output} onClick={handleCopy}>Copy</button>
        <button className="btn-action" disabled={!output} onClick={handleDownload}>Download</button>
      </div>
      <p className="mb-2 text-gray-500 text-sm">
        Paste or type your input below. Supports: JSON, YAML, XML, CSV. Converts between any formats!
      </p>
      <div className="flex gap-4">
        <textarea
          className="w-1/2 min-h-[200px] p-2 rounded border"
          value={input}
          onChange={e => setInput(e.target.value)}
          spellCheck={false}
        />
        <div className="w-1/2 min-h-[200px] bg-gray-100 dark:bg-gray-800 p-2 rounded border overflow-auto">
          {error ? (
            <span className="text-red-500">{error}</span>
          ) : (
            <pre
              className="text-xs whitespace-pre-wrap"
              dangerouslySetInnerHTML={{
                __html: Prism.highlight(output, Prism.languages[outputFormat], outputFormat),
              }}
            />
          )}
        </div>
      </div>
      <div className="mt-2 text-xs text-gray-400">
        Example: <code>{sample}</code>
      </div>
    </div>
  );
}