import React from 'react';
import { SunIcon, MoonIcon } from '@heroicons/react/24/outline';

type Props = {
  theme: string;
  setTheme: (theme: string) => void;
  search: string;
  setSearch: (val: string) => void;
};

export const TopBar: React.FC<Props> = ({ theme, setTheme, search, setSearch }) => {
  return (
    <header className="flex items-center justify-between px-4 py-2 border-b bg-white dark:bg-gray-900 dark:border-gray-800">
      <div className="text-xl font-bold tracking-tight select-none">
        Codes Convert Tool
      </div>
      <input
        id="toolbar-search"
        className="ml-4 flex-1 max-w-sm px-2 py-1 border rounded bg-gray-50 dark:bg-gray-800 dark:border-gray-700 focus:outline-none"
        placeholder="Search tools (Ctrl+K)"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        autoComplete="off"
      />
      <button
        type="button"
        aria-label="Toggle theme"
        className="ml-4 p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      >
        {theme === 'dark' ? (
          <SunIcon className="w-5 h-5" />
        ) : (
          <MoonIcon className="w-5 h-5" />
        )}
      </button>
    </header>
  );
};