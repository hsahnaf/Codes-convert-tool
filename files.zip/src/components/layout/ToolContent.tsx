import React from 'react';
import { ToolMeta } from '../tools/registry';

export const ToolContent: React.FC<{ tool: ToolMeta }> = ({ tool }) => {
  return (
    <section>
      <h1 className="text-2xl font-semibold mb-2 flex items-center">
        {tool.icon && <tool.icon className="w-7 h-7 mr-2" />}
        {tool.name}
      </h1>
      <p className="mb-4 text-gray-500 dark:text-gray-400">{tool.description}</p>
      <tool.Component />
    </section>
  );
};