import React from 'react';
import { ToolMeta, ToolKey } from '../tools/registry';
import classNames from 'classnames';

type Props = {
  tools: ToolMeta[];
  selected: ToolKey;
  setSelected: (key: ToolKey) => void;
};

export const ToolSidebar: React.FC<Props> = ({ tools, selected, setSelected }) => {
  return (
    <aside className="w-64 shrink-0 h-full overflow-y-auto border-r bg-gray-50 dark:bg-gray-950 dark:border-gray-800">
      <nav className="py-4">
        <ul>
          {tools.map((tool) => (
            <li key={tool.key}>
              <button
                className={classNames(
                  'w-full text-left px-4 py-2 my-1 rounded transition-colors',
                  selected === tool.key
                    ? 'bg-blue-600 text-white'
                    : 'hover:bg-gray-200 dark:hover:bg-gray-800'
                )}
                aria-current={selected === tool.key ? 'page' : undefined}
                onClick={() => setSelected(tool.key)}
              >
                {tool.icon && <tool.icon className="inline mr-2 w-5 h-5" />}
                {tool.name}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};